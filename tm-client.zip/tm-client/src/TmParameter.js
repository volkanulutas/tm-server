import React, { Component } from 'react';
import { Client } from '@stomp/stompjs';
import logo from './logo.svg';
import './App.css';


class TmParameter extends Component {

  state = {
        id:'',
        name: '',
        spaceSystem: '',
        includeCondition: [],
        value: '',
        receptionTimeStamp: '',
        generationTimeStamp:'',
        validity:false,
        isAlert: false,


        parameterMap:[]
  }

  componentDidMount() {
    console.log('Component did mount');
    // The compat mode syntax is totally different, converting to v5 syntax
    // Client is imported from '@stomp/stompjs'
    this.client = new Client();

    this.client.configure({
      brokerURL: 'ws://localhost:8080/stomp',
      onConnect: () => {
        console.log('onConnect');

        this.client.subscribe('/queue/now', message => {
          // console.log(message);
          this.setState({serverTime: message.body});
        });



        this.client.subscribe('/queue/parameter', message => {
                  let param = JSON.parse(message.body);
                  this.setState({name: param.name, spaceSystem: param.spaceSystem, includeCondition: param.includeCondition, value: param.value, 
                    receptionTimeStamp: param.receptionTimeStamp, generationTimeStamp: param.generationTimeStamp, 
                    isAlert: param.isAlert
                  });
                  let parameterList = [...this.state.parameterMap];

                  if(param != undefined)
                  {
                    param.isAlert = false;
                 
                    if(parameterList.length < 5)
                    {
                      this.setState({ parameterMap : [...parameterList, param]});
                    }
                    else{
                      parameterList.pop();
                      this.setState({ parameterMap : [...parameterList, param]});
                       console.log('');
                    }
                 }


                });

        this.client.subscribe('/topic/greetings', message => {
          alert(message.body);
        });
      },
      // Helps during debugging, remove in production
      debug: (str) => {
        console.log(new Date(), str);
      }
    });

    this.client.activate();
  }

  render() {
    return (
      <div className="container">

       
           <table className = "table table-dark table-hover">
             <thead>
             <th>Id:</th>
               <th>Adı</th>
               <th>Uydu</th>
               <th>Değer</th>
               <th>Alınma Zamanı</th>
               <th>Oluşturulma Zamanı</th>
               <th>Alt Sınır</th>
               <th>Üst Sınır</th>
              <th> Alarm</th>

             </thead>
             <tbody>
               {
             
               this.state.parameterMap.map(
                 t =>
                 <tr key={t.id}>
                  <td>{t.id}</td>
                   <td>{t.name}</td>
                   <td>{t.spaceSystem}</td>
                   <td>{t.value}</td>
                   <td>{t.receptionTimeStamp}</td>
                   <td>{t.generationTimeStamp}</td>
                   <td>{t.includeCondition.innerMin}</td>
                   <td>{t.includeCondition.outerMax}</td>
                   <td>{t.includeCondition.outerMax < t.value ||t.includeCondition.innerMin > t.value  ? 
                           <button type="button" class="btn btn-danger">Alert!</button>
                         : <button type="button" class="btn btn-success">Normal!</button>}</td>
                 </tr>
               )
              }
             </tbody>
           </table>



      </div>

    );
  }
}

export default TmParameter;
