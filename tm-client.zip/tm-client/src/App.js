import React, { Component } from 'react';
import { Client } from '@stomp/stompjs';
import logo from './logo.svg';
import './App.css';

import TmParameter from './TmParameter';


class App extends Component {

  state = {
    serverTime: null,
    name: '',
    shortDescription:'',
    longDescription:'',
    spaceSystem:'',
    receptionTimeStamp:'',
    generationTimeStamp:'' ,
    alarm : false,

    telemetryMap: [],
  }

  componentDidMount() {
    console.log('Component did mount');
    // The compat mode syntax is totally different, converting to v5 syntax
    // Client is imported from '@stomp/stompjs'
    this.client = new Client();

    this.client.configure({
      brokerURL: 'ws://localhost:8080/stomp',
      onConnect: () => {
        this.client.subscribe('/queue/tm', message => {
                  let tm = JSON.parse(message.body);
                  this.setState({name: tm.name,
                  shortDescription: tm.shortDescription, spaceSystem: tm.spaceSystem, receptionTimeStamp: tm.receptionTimeStamp, 
                  generationTimeStamp: tm.generationTimeStamp
                  });
                  let tmList = [...this.state.telemetryMap];

                  if(tm != undefined)
                  {
                    if(tmList.length < 5)
                    {
                      this.setState({ telemetryMap : [...tmList, tm]});
                    }
                    else{
                      tmList.pop();
                      this.setState({ telemetryMap : [...tmList, tm]});
                      console.log('');
                    }
                 }
                });
      },
    });

    this.client.activate();
  }

  clickHandler = () => {
    this.client.publish({destination: '/app/greetings', body: 'Hello world'});
  }

  render() {
    return (
      <div className="container">
          <h2> Telemetri </h2>
     
           <table className = "table table-dark table-hover">
             <thead>
               <th>Adı</th>
               <th>Açıklama</th>
               <th>Uydu</th>
               <th>Alınma Zamanı</th>
               <th>Oluşturulma Zamanı   </th>

             </thead>
             <tbody>
               {
             
               this.state.telemetryMap.map(
                 t =>
                 <tr key={t.id}>
                   <td>{t.name}</td>
                   <td>{t.shortDescription}</td>
                   <td>{t.spaceSystem}</td>
                   <td>{t.receptionTimeStamp}</td>
                   <td>{t.generationTimeStamp}</td>
                 </tr>
               )
              }
             </tbody>
           </table>
      </div>
    );
  }
}

export default App;
