package com.example.demo.payload;

import java.io.Serializable;


public class TelemetryParameter implements Serializable {
    private String id;
    private String name;
    private String spaceSystem;
    private Criteria includeCondition;
    private String value;
    private long receptionTimeStamp;
    private long generationTimeStamp;
    private boolean validity;
    private boolean isAlert;

    public TelemetryParameter(String id, String name, String spaceSystem, long receptionTimeStamp, long generationTimeStamp) {
        this.id = id;
        this.name = name;
        this.spaceSystem = spaceSystem;
        this.receptionTimeStamp = receptionTimeStamp;
        this.generationTimeStamp = generationTimeStamp;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSpaceSystem() {
        return spaceSystem;
    }

    public void setSpaceSystem(String spaceSystem) {
        this.spaceSystem = spaceSystem;
    }

    public Criteria getIncludeCondition() {
        return includeCondition;
    }

    public void setIncludeCondition(Criteria includeCondition) {
        this.includeCondition = includeCondition;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public long getReceptionTimeStamp() {
        return receptionTimeStamp;
    }

    public void setReceptionTimeStamp(long receptionTimeStamp) {
        this.receptionTimeStamp = receptionTimeStamp;
    }

    public long getGenerationTimeStamp() {
        return generationTimeStamp;
    }

    public void setGenerationTimeStamp(long generationTimeStamp) {
        this.generationTimeStamp = generationTimeStamp;
    }

    public boolean isValidity() {
        return validity;
    }

    public void setValidity(boolean validity) {
        this.validity = validity;
    }

    public boolean isAlert() {
        return isAlert;
    }

    public void setAlert(boolean alert) {
        isAlert = alert;
    }

    @Override
    public String toString() {
        return "TelemetryParameter{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", spaceSystem='" + spaceSystem + '\'' +
                ", includeCondition=" + includeCondition +
                ", value='" + value + '\'' +
                ", receptionTimeStamp=" + receptionTimeStamp +
                ", generationTimeStamp=" + generationTimeStamp +
                ", validity=" + validity +
                ", isAlert=" + isAlert +
                '}';
    }
}
