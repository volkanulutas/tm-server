package com.example.demo.service;

import com.example.demo.TmPacketGenerationUtil;
import com.example.demo.payload.TelemetryPacket;
import com.example.demo.payload.TelemetryParameter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.Instant;

@Service
public class DemoService {

    private static final Logger logger = LoggerFactory.getLogger(DemoService.class);

    private final SimpMessagingTemplate simpMessagingTemplate;

    public DemoService(SimpMessagingTemplate simpMessagingTemplate) {
        this.simpMessagingTemplate = simpMessagingTemplate;
    }

    @Scheduled(cron = "*/5 * * * * *")
    public void generatePacket() {
        TelemetryPacket packet = TmPacketGenerationUtil.generateTm("TM_003_012_009_0000", 3);

        logger.info("Scheduled task performed: " + packet.toString());
        this.simpMessagingTemplate.convertAndSend("/queue/tm", packet);
    }

    @Scheduled(cron = "*/5 * * * * *")
    public void generateParameter() {
        TelemetryParameter parameter = TmPacketGenerationUtil.generateParameter("TM_003_012_009_0000", 1);

        logger.info("Scheduled task performed: " + parameter.toString());
        this.simpMessagingTemplate.convertAndSend("/queue/parameter", parameter);
    }

    @Scheduled(cron = "*/5 * * * * *")
    public void performTask() {
        Instant now = Instant.now();
        //  logger.info("Scheduled task performed at {} (ISO 8601 date and time format)", now);
        // this.simpMessagingTemplate.convertAndSend("/queue/now", now);
    }


}
