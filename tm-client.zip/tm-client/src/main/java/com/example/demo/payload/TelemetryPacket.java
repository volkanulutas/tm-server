package com.example.demo.payload;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.io.Serializable;
import java.util.Map;


public class TelemetryPacket implements Serializable {
    private String id;
    private String name;
    private String shortDescription;
    private String longDescription;
    private String spaceSystem;
    private long receptionTimeStamp;
    private long generationTimeStamp;
    @JsonIgnore
    private Map<String, TelemetryParameter> parameterMap;

    public TelemetryPacket(String id, String name, String spaceSystem,
                           long receptionTimeStamp, long generationTimeStamp,
                           String shortDescription, String longDescription) {
        this.id = id;
        this.name = name;
        this.spaceSystem = spaceSystem;
        this.receptionTimeStamp = receptionTimeStamp;
        this.generationTimeStamp = generationTimeStamp;
        this.shortDescription = shortDescription;
        this.longDescription = longDescription;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getShortDescription() {
        return shortDescription;
    }

    public void setShortDescription(String shortDescription) {
        this.shortDescription = shortDescription;
    }

    public String getLongDescription() {
        return longDescription;
    }

    public void setLongDescription(String longDescription) {
        this.longDescription = longDescription;
    }

    public String getSpaceSystem() {
        return spaceSystem;
    }

    public void setSpaceSystem(String spaceSystem) {
        this.spaceSystem = spaceSystem;
    }

    public long getReceptionTimeStamp() {
        return receptionTimeStamp;
    }

    public void setReceptionTimeStamp(long receptionTimeStamp) {
        this.receptionTimeStamp = receptionTimeStamp;
    }

    public long getGenerationTimeStamp() {
        return generationTimeStamp;
    }

    public void setGenerationTimeStamp(long generationTimeStamp) {
        this.generationTimeStamp = generationTimeStamp;
    }

    public Map<String, TelemetryParameter> getParameterMap() {
        return parameterMap;
    }

    public void setParameterMap(Map<String, TelemetryParameter> parameterMap) {
        this.parameterMap = parameterMap;
    }

    @Override
    public String toString() {
        return "TelemetryPacket{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", shortDescription='" + shortDescription + '\'' +
                ", longDescription='" + longDescription + '\'' +
                ", spaceSystem='" + spaceSystem + '\'' +
                ", receptionTimeStamp=" + receptionTimeStamp +
                ", generationTimeStamp=" + generationTimeStamp +
                ", parameterMap=" + parameterMap +
                '}';
    }
}
