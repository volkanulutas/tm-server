package com.example.demo.payload;

import java.io.Serializable;


public class Criteria implements Serializable {
    private double innerMax;
    private double innerMin;
    private double outerMin;
    private double outerMax;

    public Criteria(double innerMax, double innerMin, double outerMin, double outerMax) {
        this.innerMax = innerMax;
        this.innerMin = innerMin;
        this.outerMin = outerMin;
        this.outerMax = outerMax;
    }

    public double getInnerMax() {
        return innerMax;
    }

    public void setInnerMax(double innerMax) {
        this.innerMax = innerMax;
    }

    public double getInnerMin() {
        return innerMin;
    }

    public void setInnerMin(double innerMin) {
        this.innerMin = innerMin;
    }

    public double getOuterMin() {
        return outerMin;
    }

    public void setOuterMin(double outerMin) {
        this.outerMin = outerMin;
    }

    public double getOuterMax() {
        return outerMax;
    }

    public void setOuterMax(double outerMax) {
        this.outerMax = outerMax;
    }

    @Override
    public String toString() {
        return "Criteria{" +
                "innerMax=" + innerMax +
                ", innerMin=" + innerMin +
                ", outerMin=" + outerMin +
                ", outerMax=" + outerMax +
                '}';
    }
}
