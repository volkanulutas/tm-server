package tr.com.tai.mcs.tmgenerator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TmGeneratorApplicationTests {

	@Test
	void contextLoads() {
	}

}
