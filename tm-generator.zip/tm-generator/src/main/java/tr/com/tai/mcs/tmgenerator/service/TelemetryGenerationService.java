package tr.com.tai.mcs.tmgenerator.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;
import tr.com.tai.mcs.tmgenerator.amqp.EventPublisherService;
import tr.com.tai.mcs.tmgenerator.amqp.Events;
import tr.com.tai.mcs.tmgenerator.data.TelemetryPacket;
import tr.com.tai.mcs.tmgenerator.socket.config.WebSocketConfiguration;

import java.io.IOException;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

@Service
public class TelemetryGenerationService {

    // @Autowired
    // private EventPublisherService eventPublisherService;

    private final SimpMessagingTemplate websocket;


    private ScheduledExecutorService service =  Executors.newScheduledThreadPool(1);

    @Autowired
    public TelemetryGenerationService(SimpMessagingTemplate websocket) {
        this.websocket = websocket;
    }


    public void sendPacket(TelemetryPacket packet) {
       // System.out.println("Telemetry packet sent. " + packet.toString());
        this.websocket.convertAndSend(
                WebSocketConfiguration.MESSAGE_PREFIX + "/newTelemetry", packet);
    }

    public boolean startGeneration() {
        try {

            service.scheduleAtFixedRate(() -> {
                TelemetryPacket packet = TmPacketGenerationUtil.generateTm("TM_003_012_009_0000", 3);
                //  eventPublisherService.publishEvent(Events.Event1, packet);
                sendPacket(packet);

            }, 0, 1000L, TimeUnit.MILLISECONDS);
            return true;
        } catch (Exception ex) {
            return false;
        }
    }

    public boolean stopGeneration() {
        try {
            service.shutdownNow();
        } catch (Exception ex) {
            return false;

        }
        return true;
    }
}

