package tr.com.tai.mcs.tmgenerator.amqp;

public final class Constants {
    public static final String queueName = "MCS.Telemetry";
}
