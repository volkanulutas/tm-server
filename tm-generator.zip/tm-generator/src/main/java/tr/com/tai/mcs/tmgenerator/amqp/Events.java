package tr.com.tai.mcs.tmgenerator.amqp;

public enum Events {
    Event1,
    Event2;
}

